from flask import Flask, render_template, request, jsonify
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer

# Step 1: Create a Flask app
app = Flask(__name__)

# Step 2: Create a chatbot instance
chatbot = ChatBot(
    'WebBot',  # Name of the chatbot
    logic_adapters=[
        {
            'import_path': 'chatterbot.logic.BestMatch',  # Use the BestMatch logic adapter
            'default_response': 'I am sorry, I do not understand.',  # Default response
            'maximum_similarity_threshold': 0.90  # Adjust similarity threshold
        }
    ]
)

# Step 3: Train the chatbot on the English corpus
trainer = ChatterBotCorpusTrainer(chatbot)
trainer.train("chatterbot.corpus.english")

# Step 4: Define the home route
@app.route("/")
def home():
    return render_template("index.html")  # Render the HTML template

# Step 5: Define the API route for chatbot responses
@app.route("/get")
def get_bot_response():
    user_input = request.args.get("msg")  # Get user input from the request
    response = str(chatbot.get_response(user_input))  # Get chatbot response
    return jsonify(response=response)  # Return the response as JSON

# Step 6: Run the Flask app
if __name__ == "__main__":
    app.run(debug=True)